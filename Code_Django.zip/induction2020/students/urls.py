from django.urls import path

from . import views

urlpatterns = [
    path('', views.upload_file, name="index"),
    path('scraper/', views.update_scraper, name="scraper")
]

