from django import forms

class UploadProfileForm(forms.Form):
    rollnumber = forms.CharField(max_length=50)
    file = forms.FileField()