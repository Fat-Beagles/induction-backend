from django.contrib import admin

# Register your models here.
from .models import Profile, Gallery, TweetUpdate

class TweetUpdateAdmin(admin.ModelAdmin):
    # date_hierarchy = 'pub_date'
    list_display = ('tweetid', 'status', 'pub_date')

admin.site.register(Profile)
admin.site.register(Gallery)
admin.site.register(TweetUpdate, TweetUpdateAdmin)