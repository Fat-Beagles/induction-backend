from django.db import models
from datetime import datetime   
from django.utils import timezone
from django.utils.timezone import now

# Create your models here.
class Profile(models.Model):
    rollnumber = models.CharField(max_length=50, unique=True, blank=False)
    image = models.ImageField(upload_to='uploads/', blank=False, null=False)
    pub_date = models.DateTimeField('date published', default=datetime.now, blank=True)

    def __str__(self):
        return self.rollnumber

class Gallery(models.Model):
    eventname = models.CharField(max_length=100, blank=False, default="IIITD Induction Event")
    eventnum = models.CharField(max_length=10, unique=True, blank=False)
    image = models.ImageField(upload_to='events/', blank=False, null=False)
    pub_date = models.DateTimeField('date published', default=datetime.now, blank=True)

    def __str__(self):
        return self.eventnum + " | " + self.eventname
        
class TweetUpdate(models.Model):
    tweetid = models.CharField(max_length=100, blank=False)
    status = models.CharField(max_length=100, blank=False, default='Done')
    pub_date = models.DateTimeField('date published', default=now, blank=True)
    def __str__(self):
        return self.tweetid + " ------ " + self.status
        