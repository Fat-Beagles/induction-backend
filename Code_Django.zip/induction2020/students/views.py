from django.shortcuts import render
from django.http import HttpResponse
from PIL import Image
from .models import Profile, TweetUpdate
from .forms import UploadProfileForm
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

# Create your views here.

@csrf_exempt
def upload_file(request):
    #print(dir(request), request.body)
    if request.method == 'POST':
        form = UploadProfileForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                img = Image.open(request.FILES['file'])
                img.verify()
                print('Valid image')
            except Exception:
                print('Invalid image')
                return JsonResponse({'success': 1, 'msg': 'Invalid Image'})
            instance, created = Profile.objects.update_or_create(rollnumber=form.cleaned_data['rollnumber'], defaults={'image':request.FILES['file'] })
            # if created:
            instance.save()
            #person, created = Person.objects.get_or_create(identifier=id)
            #else:
            if created:
                return JsonResponse({'success': 0, 'url': instance.image.url, 'msg': 'Everything is awesome!'})
            else:
                return JsonResponse({'success': 0, 'url': instance.image.url, 'msg': 'Image updated!'})
        else:
            print(form)
            return JsonResponse({'success': 1, 'msg': 'Form is not valid', 'form': form})
    else:
        form = UploadProfileForm()
    return render(request, 'upload.html', {'form': form})

@csrf_exempt
def update_scraper(request):
    try:
        tweetid = request.GET.get('tweetid', "ErrorTweetID")
        status = request.GET.get('status', 'ERROR')
        instance = TweetUpdate.objects.create(tweetid=tweetid, status=status)
        instance.save()
        return JsonResponse({'success': 0, 'msg': 'No error!'})
    except: 
        return JsonResponse({'success': 1, 'msg': 'Error has occured!'})
    
